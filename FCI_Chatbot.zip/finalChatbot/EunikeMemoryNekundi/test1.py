import random
def choices():
    print("Please choose what you would like to do.")
    choice = int(input("For Sigining Up Type 1 and For Signing in Type 2: "))
    if choice == 1:
       print("Please select Category:")
       print("1. Student")
       print("2. Applicant")
       print("3. Visitor")
       category = int(input("enter number here: "))
       if category == 1:
           return getdetails1()
       if category == 2:
           return getdetails2()
       if category == 3:
           return getdetails2()
       if category == 4:
           return null
    if choice == 2:
       print("Please select Category:")
       print("1. Student")
       print("2. Applicant")
       print("3. Visitor")
       category = int(input("enter number here: "))
       if category == 1:
           return checkdetails1()
       if category == 2:
           return checkdetails2()
       if category == 3:
           return checkdetails2()
       if category == 4:
           return null
    else:
       raise TypeError

def getdetails1():
    print("Please Provide")
    f_name = str(input("First Name: "))
    s_name = str(input("Second Name: "))
    name = str(input("Student number: "))
    password = str(input("Password: "))
    f = open("student.txt",'r')
    info = f.read()
    if name in info:
        return "Student Number already taken. Please Try Again"
    f.close()
    f = open("student.txt",'w')
    info = info + " " +f_name + " " +s_name + " " +name + " " + password
    f.write(info)

def getdetails2():
    print("Please Provide")
    f_name = str(input("First Name: "))
    s_name = str(input("Second Name: "))
    name = random.randint(100000000,999999999)
    name2 = str(name)
    f = open("applicant.txt",'r')
    info = f.read()
    if name2 in info:
        return "Name Unavailable. Please Try Again"
    f.close()
    password = str(input("Password: "))
    f = open("applicant.txt",'w')
    info = info+ "Your applicant number is: " + str(name2) + " " + password + " " +f_name + " " +s_name
    f.write(info)
    print("your applicant number is:  " + str(name2))

def getdetails3():
    print("Please Provide")
    f_name = str(input("First Name: "))
    s_name = str(input("Second Name: "))
    name = str(input("Unique Id: "))
    password = str(input("Password: "))
    f = open("visitor.txt",'r')
    info = f.read()
    if name in info:
        return "Name Unavailable. Please Try Again"
    f.close()
    f = open("visitor.txt",'w')
    info = info + " " +name + " " + password + " " +f_name + " " +s_name
    f.write(info)

def checkdetails1():
    print("Please Provide")
    name = str(input("Student Number : "))
    password = str(input("Password: "))
    f = open("student.txt",'r')
    info = f.read()
    info = info.split()
    if name in info:
        index = info.index(name) + 1
        usr_password = info[index]
        if usr_password == password:
            return "Welcome Back, " + name
        else:
            return "Password entered is wrong"
    else:
        return "Name not found. Please Sign Up."
    
def checkdetails2():
    print("Please Provide")
    name = str(input("applicant number: "))
    password = str(input("Password: "))
    f = open("applicant.txt",'r')
    info = f.read()
    info = info.split()
    if name in info:
        index = info.index(name) + 1
        usr_password = info[index]
        if usr_password == password:
            return "Welcome Back, " + name
        else:
            return "Password entered is wrong"
    else:
        return "Name not found. Please Sign Up."

def checkdetails3():
    print("Please Provide")
    name = str(input("unique Id: "))
    password = str(input("Password: "))
    f = open("visitor.txt",'r')
    info = f.read()
    info = info.split()
    if name in info:
        index = info.index(name) + 1
        usr_password = info[index]
        if usr_password == password:
            return "Welcome Back, " + name
        else:
            return "Password entered is wrong"
    else:
        return "Name not found. Please Sign Up."


print(choices())
